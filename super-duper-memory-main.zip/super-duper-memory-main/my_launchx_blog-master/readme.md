![banner](https://user-images.githubusercontent.com/17634377/155042185-d8a46812-04aa-4534-88e6-cdfb8b3f02f6.png)

## My Launch X Blog: Bitácora de Viaje 🚀

Hola explorer 👋 

Realiza las indicaciones de la weekly mission y monta tu propio blog. Espero que te sirva como bitácora de aprendizaje para compartir todas tus experiencias de Launch X. 

Así como también puedes crear tu **Workbook**:

![Ilustración_sin_título 2](https://user-images.githubusercontent.com/17634377/156294681-a7d2feb4-d41e-464f-9dbf-0fbc781aa056.png)
