---
title: Launch X Bitácora de viaje
description: The hallway smelt of boiled cabbage and old rag mats.
---

Hola ✌️  soy el explorer **___** y este es mi blog personal donde compartiré mis aventuras de Launch X.

Te invito a conocer mis aprendizajes y leer mis experiencias.

🚀
