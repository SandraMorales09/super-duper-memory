---
title: "Mis expectativas"
date: 2022-02-21T18:16:21-06:00
description: 'Este es mi primer post de la travesía en la Misión de Backend con Node JS de Launch X.'
---

Usa este post para anotar tus expectativas de la misión.
