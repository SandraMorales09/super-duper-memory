# Launch X Node JS Playbook 🚀 de @explorername

<img width="1247" alt="image" src="https://user-images.githubusercontent.com/17634377/159151704-8949639b-ae5f-405a-a8b8-8d97f3f150cd.png">

Repositorio para guardar las prácticas de Launch X.
